const userModel = require('../models/userModel')
const usersList = async(req,res,next)=>{
    let projection ={}
    if(req.query.hasOwnProperty('fields') ){
       projection = req.query.fields.split(',').reduce(( total , current)=>{
        return{[current]:1 , ...total}
       },{})
       console.log(projection)
    }
    const perPage = 1
    const page = req.query.page || 1
    const offset = (page-1) * perPage
    const userCount = await userModel.count()
    const totalPage= Math.ceil(userCount / perPage)
    const users = await userModel.find({},projection).limit(perPage).skip(offset)
    res.send({
        success:true,
        message:'لیست کاربران با موفقیت اجرا شد',
        data:{
          users
        },
        meta:{
   
            page:totalPage,
            next:hasNextPage(page,totalPage) ? `${process.env.APP_URL}/api/v1/users?page=${page +1}`: null,
            prev:hasPrevPage(page , totalPage) ?`${process.env.APP_URL}/api/v1/users?page=${page - 1}` : null
        }
    })
}

const addUser = async (req,res , next)=>{
    try {
        const {first_name,last_name,mobile,email} = req.body
        if(first_name == ""  || last_name == ""){
         return   res.status(422).send({
                error:true,
                message:"اطلاعات ارسالی درست نمیباشد"
            })
        }
        const newUser = new userModel({
            first_name,
            last_name,
            mobile,
            email
        })
        await newUser.save()
        res.status(201).send({
            success:true,
            status:200,
            message: 'new user add successfully',
            newuserId: newUser._id,
            newUser
        })
    } catch (error) {
        next(error)
    }
}

const getUser = async(req,res,next)=>{
       try {
           const {id} = req.params
           if(!id){
            return res.status(404).send({error:true , message:'user with this id is not exist'})
           }
           const user = await userModel.findOne({_id:id})
           if(!user){
            return res.status(404).send({error:true , message:'user with this id is not exist'})
           }
           return res.status(200).send({
            success:true,
            data:{
                user
            }
           })
       } catch (error) {
          next(error)
       }
}
const removeUser = async(req,res,next)=>{
 try {
    const {id} = req.params
    if(!id){
     return res.status(404).send({error:true , message:'user with this id is not exist'})
    }
    await userModel.deleteOne({_id:id}, {...req.body})
    res.send({
        success:true,
        message:`deleted successfully on `
    })
 } catch (error) {
    next(error)
 }
}

const updateUser = async (req,res,next)=>{
    try {
        const {id} = req.params
        if(!id){
         return res.status(404).send({error:true , message:'user with this id is not exist'})
        }
       const {n , nModified} =  await userModel.updateOne({_id:id},{...req.body})
       if(n===0 || nModified === 0){
        throw new Error('no operation found')
       }
        res.send({
            success:true,
            message:`updated successfully on `
        })
     } catch (error) {
        next(error)
     }
}

const hasNextPage = (page,totalPage)=>{
    return page< totalPage
}
const hasPrevPage = (page,totalPage)=>{
    return page > 1
}
module.exports = {
    usersList,
    addUser,
    getUser,
    removeUser,
    updateUser
}