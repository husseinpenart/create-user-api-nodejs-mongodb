const startMongo = require('./mongo')
startMongo()