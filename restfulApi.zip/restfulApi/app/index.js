const express = require('express');
const app= express()
require('./boot')
require('./middlewares')(app);
require('./routes')(app);
require('./middlewares/exeption')(app)
require('./middlewares/404')(app)
module.exports = (port)=>{
   app.listen(port , ()=>{
       console.log(`app is runing on port ${port}`)
   })
}